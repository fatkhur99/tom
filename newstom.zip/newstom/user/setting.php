<?php
/* setting bot */

$ads=$ijo."    [ official chanel adi bordir ]".$t.$red."\t >> subcribe chanel << ".$t.$pth."[ ".$ijo."AW 2000".$pth." ]=[".$kn." MK KHAIRIL ".$pth."]=[ ".$tr."HĂN C_GAMER ]".$t;

$donasi=false;

$warn=$red."[!] warning !!!
".$kn."[-] ini adalah program ilegal
".$kn."[-] resiko sepenuhnya di tanggung pengguna".$t;


$baca_plus=$red."
──── █▀▄ ▄▀▄ ▄▀ ▄▀▄────$kuning █▀▄ █── █─█ ▄▀▀────$red
──── █▀█ █▀█ █─ █▀█────$kuning █─█ █─▄ █─█ ─▀▄────$red
──── ▀▀─ ▀─▀ ─▀ ▀─▀────$kuning █▀─ ▀▀▀ ─▀─ ▀▀─────$putih
creator:$ijo adidoank$putih || code invite:$ijo F9NAmmRD7x$putih
chanel :$kuning sungging$putih || code invite:$ijo F3NW34owm4".$t;
$msg_baca= "[•] official chanel adi bordir".$t."[•] update skrip fix error 14/02/2019";
$stat_baca=true;
 
$ccu= $red."
──── ▄▀ ▄▀▄ ▀ █▄─█──── ▄▀ █── █─█ █▀▄────".$pth."
──── █─ █─█ █ █─▀█──── █─ █─▄ █─█ █▀█────
──── ─▀ ─▀─ ▀ ▀──▀──── ─▀ ▀▀▀ ─▀─ ▀▀─────
creator: ".$ijo."adidoank ".$pth."|| chanel: ".$ijo."adi bordir".$t;
$msg_ccu=$ijo."[•] official chanel adi bordir dan sungging";
$stat_ccu=true;

$mc=$br."
──── █▄─▄█ ▄▀▄ █▄─█ █▀▀ ▀▄─▄▀──── ▄▀ █─█ █▀▄ █▀▀────
──── █─█─█ █─█ █─▀█ █▀▀ ──█────── █─ █─█ █▀█ █▀▀────
──── ▀───▀ ─▀─ ▀──▀ ▀▀▀ ──▀────── ─▀ ─▀─ ▀▀─ ▀▀▀────
".$pth."creator: ".$ijo."adidoank ".$pth."|| ".$ijo."subcribe chanel adi bordir".$t.$pth."invite : ".$ijo."YCUSP ".$pth."|| ".$ijo."W9HVQ
".$pth."support: ".$ijo."subcribe chanel sungging".$t;
$msg_mc=$ijo."[•] This script doesn't work".$t."[•] skrip coid";
$stat_mc=true;

$flash="$red
 █▀──── █────── ▄▀▄──── ▄▀▀──── █────── ▄▀▀───── ▄▀▄
 █▀──── █─▄──── █▀█──── ─▀▄──── █▀▄──── █─▀▌──── █─█
 ▀───── ▀▀▀──── ▀─▀──── ▀▀───── ▀─▀──── ▀▀▀───── ─▀─
$putih  creator :$ijo adidoank$putih ||||| chanel :$turkis adi bordir".$t."$putih  support :$ijo sungging$putih ||||| chanel :$turkis sungging";
$msg_flash=$turkis."[•] flash go";
$stat_flash=true;

$yogov= $kuning."
 ▀▄─▄▀ ▄▀▄ ▄▀▀─ ▄▀▄──── ▐▌─▐▌ ▀ █▀▄ █▀▀ ▄▀▄
 ──█── █─█ █─▀▌ █─█──── ─▀▄▀─ █ █─█ █▀▀ █─█
 ──▀── ─▀─ ▀▀▀─ ─▀───── ──▀── ▀ ▀▀─ ▀▀▀ ─▀─".$t.
$ijo."[ v 1.0 ] ".$putih."creator: ".$ijo."adidoank".$t.">> subcribe chanel adi bordir".$t.">> subcribe chanel sungging".$t;
$msg_yogo=$ijo."[•] enjoy your life";
$stat_yogo=true;
$yogo=["tes"];

$wot=$pth."
    ___ Wheel __       __O_f__        _Trust__".$red."
    __ |     / / ".$kn."      __  __ \ ".$ijo."      ___  __/".$red."
    __ | /| / /  ".$kn."      _  / / / ".$ijo."      __  /   ".$red."
    __ |/ |/ /  ".$kn."       / /_/ /  ".$ijo."      _  /    ".$red."
    ____/|__/   ".$kn."       \____/   ".$ijo."      /_/     ".$pth."
========[ v 1.0 ][creator: adidoank]========".$t;
$stat_wot=false;
$msg_wot=$ijo."[•] skrip dalam perbaikan";


$emon=$ijo."
──── █▀▀──── █▄─▄█──── ▄▀▄──── █▄─█────
──── █▀▀──── █─█─█──── █─█──── █─▀█────
──── ▀▀▀──── ▀───▀──── ─▀───── ▀──▀────".$pth."
==[creator:".$ijo." adidoank".$pth."]=|=".$tr."[ v : 1 . 0 ]".$pth."==".$t;
$stat_emon=true;
$auto_ref=true;
$msg_emon= $ijo."[•] enjoy your life";

$you_me=$red."
──── ▀▄─▄▀ ▄▀▄ █─█──── █▄─▄█ █▀▀────
──── ──█── █─█ █─█──── █─█─█ █▀▀────
──── ──▀── ─▀─ ─▀───── ▀───▀ ▀▀▀────".$t.$pth."========".$ijo."[creator : adidoank]".$pth."========".$t;
$youme=true;
$msg_you=$ijo."[•] enjoy your life";

$ltc=$red."
_______________________________________
    _| [".$ijo."ROOT".$red."]  _|  ".$ijo." |||||||||||||||||||".$red."                   
    _|       _|_|_|_|       _|_|_|      
    _|         _|         _|            
    _|  __     _|         _|         
_____|____|__".$ijo."I".$red."__|_|___".$ijo."E".$red."____|_|_|_|_".$ijo."OIN_".$pth."
[ v.1.0 ]========[ creator : adidoank ] ".$t;
$msg_ltc="[•] enjoy your life";
$do_ltc=false;
$stat_ltc=true;

$eth_far=$tr."
──── █▀▀ ▀█▀ █────── █▀ ▄▀▄ █▀▀▄ █▄─▄█ █▀▀ █▀▀▄────
──── █▀▀ ─█─ █▀▄──── █▀ █▀█ █▐█▀ █─█─█ █▀▀ █▐█▀────
──── ▀▀▀ ─▀─ ▀─▀──── ▀─ ▀─▀ ▀─▀▀ ▀───▀ ▀▀▀ ▀─▀▀────
======[".$ijo." version 1.0".$tr." ]===[ creator:".$ijo." adidoank".$tr." ]======".$t;
$msg_eth_far=$ijo."[•] enjoy your life";
$stat_eth_far=true;

$ice=$br."
──── ▀ ▄▀ █▀▀──── █▀▄ █▀▀▄ █▀▀ ▄▀▄ █─▄▀ █▀▀ █▀▀▄────
──── █ █─ █▀▀──── █▀█ █▐█▀ █▀▀ █▀█ █▀▄─ █▀▀ █▐█▀────
──── ▀ ─▀ ▀▀▀──── ▀▀─ ▀─▀▀ ▀▀▀ ▀─▀ ▀─▀▀ ▀▀▀ ▀─▀▀────".$pth."
|||=============[".$ijo." creator: adioank".$pth." ]=============|||".$t;
$msg_ice=$ijo."[•]=[info]".$t.
"[-] update lagi icebreaker 13 maret tutor chanel ytb adi bordir".$t;

$stat_ice=true;

$epi=$kn."
 █▀▀──── █▀▄──── ▀──── ▄▀──── ▄▀▄──── ▄▀▀──── █──
 █▀▀──── █─█──── █──── █───── █▀█──── ─▀▄──── █▀▄
 ▀▀▀──── █▀───── ▀──── ─▀──── ▀─▀──── ▀▀───── ▀─▀
 ".$pth."[ ".$tr."v 1.0".$pth." ]==[ ".$tr."creator:".$ijo." adidoank".$pth." ]==[".$tr." ref: ".$ijo."TVFG9W".$pth." ]".$t;
$msg_epi=$ijo."[•] update skrip https://github.com/adidoank/epicash".$t.$pth."[support:".$tr." khairil".$pth."][Kode: ".$ijo."ZAVGFX]".$t;
$stat_epi1=true;

$cash= $br."
 ▄▀ ▄▀▄ ▄▀▀ █────── █───█ ▄▀▄ █── █── █▀▀ ▀█▀
 █─ █▀█ ─▀▄ █▀▄──── █─█─█ █▀█ █─▄ █─▄ █▀▀ ─█─
 ─▀ ▀─▀ ▀▀─ ▀─▀──── ─▀─▀─ ▀─▀ ▀▀▀ ▀▀▀ ▀▀▀ ─▀─
====[".$ijo." version 1.0".$br." ]=[ creator:".$ijo." adidoank".$br." ]====".$t;
$msg_cash=$ijo."[•] enjoy your life";
$stat_cash=true;


$spbu=$pth."
 ==[ s  p  i  n  n  i  n  g   b  u  c  k  s ]==".$red."
 _______".$kn."       _____ ".$ijo."      ______ ".$br."      _     _".$red."
 |______".$kn."      |_____]".$ijo."      |_____]".$br."      |     |".$red."
 ______|".$kn."      |      ".$ijo."      |_____]".$br."      |_____|".$pth."
 ======[ ".$tr."v 1.0".$pth." ]====[ ".$tr."creator: ".$br."adidoank".$pth." ]======".$t;
$msg_spbu=$ijo."[•] enjoy your life";
$stat_spbu=true;

$cbn=$tr."                                                          
[v 1.0]".$red."_|_|_|".$pth."creator".$red."_|_|_|".$ijo." adidoank".$red."_|".$kn." C B N".$red."_|              
     _|             _|    _|       _|_|    _|              
     _|             _|_|_|         _|  _|  _|              
     _|             _|    _|       _|    _|_|              
     _|_|_|         _|_|_|         _|      _|".$br."           
_[ T h e ]__".$kn."[ B i t c o i n ]__".$ijo."[ W h e e l ]_".$t;
$msg_cbn=$ijo."[•] enjoy your life";
$stat_cbn=true;

$newstom= $br."
 █▄─█ █▀▀ █───█ ▄▀▀──── ▀█▀ ▄▀▄ █▄─▄█
 █─▀█ █▀▀ █─█─█ ─▀▄──── ─█─ █─█ █─█─█
 ▀──▀ ▀▀▀ ─▀─▀─ ▀▀───── ─▀─ ─▀─ ▀───▀".$pth."
    [v 1.0 ]=[".$tr." creator: ".$ijo."adidoank".$pth." ]".$t.$tr;
$msg_tom=$ijo."[•] enjoy your life";
$stat_tom=true;

$glu=$ijo."
____ _    _  _ _ _ _ ____ ____ ___  ____    
| __ |    |  | | | | |__| |__/ |  \ [__     
|__] |___ |__| |_|_| |  | |  \ |__/ ___]".$pth."    
----------------------------------------".$tr."
[===[ ".$pth."v 1.0".$tr." ]==[".$pth." creator:".$ijo." adidoank".$tr." ]===]".$pth."
----------------------------------------".$t;
$msg_glu=$ijo."[•] enjoy your life";
$stat_glu=true;

$yogop= $kuning."
 ▀▄─▄▀ ▄▀▄ ▄▀▀─ ▄▀▄──── ▐▌─▐▌ ▀ █▀▄ █▀▀ ▄▀▄
 ──█── █─█ █─▀▌ █─█──── ─▀▄▀─ █ █─█ █▀▀ █─█
 ──▀── ─▀─ ▀▀▀─ ─▀───── ──▀── ▀ ▀▀─ ▀▀▀ ─▀─".$t.
$ijo."[ v ".$v." ] ".$putih."creator: ".$ijo."adidoank".$t;
$msg_yogop=$ijo."[•] enjoy your life";
$stat_yogop=true;

?>
